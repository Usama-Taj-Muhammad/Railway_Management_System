import React from 'react';
import './MainPage.css';

export default function MainPage() {
  return (
    <div
      className="mainpage-container"
      style={{
        minHeight: 'calc(100vh - 60px)',
        backgroundImage: "url('/train-bg.jpg')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        color: 'white',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column',
        textShadow: '1px 1px 4px black',
        paddingTop: '40px'
      }}
    >
      <h1 className="fade-slide-down">Welcome to Railway Management System</h1>
      <p className="fade-in-delay">Book your train tickets easily and quickly.</p>
    </div>
  );
}
