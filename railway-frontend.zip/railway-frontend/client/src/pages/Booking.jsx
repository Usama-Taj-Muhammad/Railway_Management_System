import React, { useState, useEffect } from 'react';
import '../BackgroundStyles.css';

export default function Booking() {
  const [userId, setUserId] = useState('');
  const [trainId, setTrainId] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [seatsBooked, setSeatsBooked] = useState(1);
  const [message, setMessage] = useState('');
  const [bookings, setBookings] = useState([]);
  const [trains, setTrains] = useState([]);

  useEffect(() => {
    fetchBookings();
    fetchTrains();
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await fetch('http://localhost:5003/api/bookings');
      const data = await response.json();
      setBookings(data);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    }
  };

  const fetchTrains = async () => {
    try {
      const response = await fetch('http://localhost:5002/api/trains');
      const data = await response.json();
      setTrains(data);
    } catch (error) {
      console.error('Error fetching trains:', error);
    }
  };

  // Moved this here to fix ESLint warning
  const getTrainName = (id) => {
    const train = trains.find((t) => t._id === id);
    return train ? train.name : id;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!userId || !trainId || !bookingDate || !seatsBooked) {
      setMessage('Please fill all fields');
      return;
    }

    try {
      const response = await fetch('http://localhost:5003/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, trainId, bookingDate, seatsBooked }),
      });

      if (response.ok) {
        setMessage('Booking successful!');
        setUserId('');
        setTrainId('');
        setBookingDate('');
        setSeatsBooked(1);
        fetchBookings();
      } else {
        const errorData = await response.json();
        setMessage('Booking failed: ' + (errorData.message || 'Unknown error'));
      }
    } catch (error) {
      setMessage('Error: ' + error.message);
    }
  };

  return (
    <div
      className="page-container"
      style={{
        backgroundImage: "url('/booking-bg.jpg')",
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        padding: '2rem',
        gap: '3rem',
        minHeight: '100vh',
      }}
    >
      {/* Form container */}
      <div
        className="form-container"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
          padding: '2rem',
          borderRadius: '12px',
          minWidth: '320px',
          color: '#fff',
          boxShadow: '0 0 15px rgba(0,0,0,0.7)',
        }}
      >
        <h2>Book a Train</h2>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <input
            type="text"
            value={userId}
            placeholder="Enter your User ID"
            onChange={(e) => setUserId(e.target.value)}
            required
            style={{ padding: '8px', borderRadius: '6px', border: 'none' }}
          />
          <select
            value={trainId}
            onChange={(e) => setTrainId(e.target.value)}
            required
            style={{
              padding: '8px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: '#f0f0f0',
              color: '#000',
            }}
          >
            <option value="">Select Train</option>
            {trains.map((train) => (
              <option key={train._id} value={train._id}>
                {train.name} ({train._id})
              </option>
            ))}
          </select>
          <input
            type="date"
            value={bookingDate}
            onChange={(e) => setBookingDate(e.target.value)}
            required
            style={{ padding: '8px', borderRadius: '6px', border: 'none' }}
          />
          <input
            type="number"
            min="1"
            value={seatsBooked}
            onChange={(e) => setSeatsBooked(Number(e.target.value))}
            required
            style={{ padding: '8px', borderRadius: '6px', border: 'none' }}
          />
          <button
            type="submit"
            style={{
              padding: '10px',
              borderRadius: '6px',
              backgroundColor: '#007bff',
              border: 'none',
              color: 'white',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            Book Now
          </button>
        </form>
        {message && (
          <p className="message" style={{ marginTop: '1rem', color: '#ffcc00' }}>
            {message}
          </p>
        )}
      </div>

      {/* Bookings list container */}
      <div
        style={{
          flex: 1,
          maxWidth: '700px',
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
          borderRadius: '12px',
          padding: '1rem',
          color: '#fff',
          boxShadow: '0 0 15px rgba(0,0,0,0.7)',
          overflowX: 'auto',
        }}
      >
        <h3>All Bookings</h3>
        {bookings.length === 0 ? (
          <p>No bookings yet.</p>
        ) : (
          <table
            style={{
              width: '100%',
              borderCollapse: 'collapse',
              color: '#fff',
            }}
          >
            <thead>
              <tr style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}>
                <th style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.3)' }}>User ID</th>
                <th style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.3)' }}>Train Name</th>
                <th style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.3)' }}>Date</th>
                <th style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.3)' }}>Seats</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b, index) => (
                <tr
                  key={index}
                  style={{
                    backgroundColor: index % 2 === 0 ? 'rgba(255, 255, 255, 0.05)' : 'transparent',
                  }}
                >
                  <td style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>{b.userId}</td>
                  <td style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                    {getTrainName(b.trainId)}
                  </td>
                  <td style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                    {b.bookingDate?.substring(0, 10)}
                  </td>
                  <td style={{ padding: '10px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>{b.seatsBooked}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}