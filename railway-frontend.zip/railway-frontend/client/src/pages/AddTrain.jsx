import React, { useState } from 'react';
import '../BackgroundStyles.css';

export default function AddTrain() {
  const [name, setName] = useState('');
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [departureTime, setDepartureTime] = useState('');
  const [arrivalTime, setArrivalTime] = useState('');
  const [seatsAvailable, setSeatsAvailable] = useState(0);
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name || !source || !destination || !departureTime || !arrivalTime || seatsAvailable <= 0) {
      setMessage('Please fill in all fields with valid values.');
      return;
    }

    const trainData = {
      name,
      source,
      destination,
      departureTime,
      arrivalTime,
      seatsAvailable,
    };

    try {
      const res = await fetch('http://localhost:5002/api/trains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(trainData),
      });

      if (res.ok) {
        setMessage('Train added successfully!');
        setName('');
        setSource('');
        setDestination('');
        setDepartureTime('');
        setArrivalTime('');
        setSeatsAvailable(0);
      } else {
        const errorData = await res.json();
        setMessage('Failed to add train: ' + (errorData.message || 'Unknown error'));
      }
    } catch (error) {
      setMessage('Error: ' + error.message);
    }
  };

  return (
    <div className="page-container" style={{ backgroundImage: "url('/addtrain-bg.jpg')" }}>
      <div className="form-container" style={{ maxWidth: '500px' }}>
        <h2>Add New Train</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Train Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Source"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Destination"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            required
          />
          <input
            type="time"
            placeholder="Departure Time"
            value={departureTime}
            onChange={(e) => setDepartureTime(e.target.value)}
            required
          />
          <input
            type="time"
            placeholder="Arrival Time"
            value={arrivalTime}
            onChange={(e) => setArrivalTime(e.target.value)}
            required
          />
          <input
            type="number"
            placeholder="Seats Available"
            value={seatsAvailable}
            min={1}
            onChange={(e) => setSeatsAvailable(Number(e.target.value))}
            required
          />
          <button type="submit">Add Train</button>
        </form>
        {message && <p className="message">{message}</p>}
      </div>
    </div>
  );
}
