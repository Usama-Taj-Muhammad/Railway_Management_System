import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';  // <-- import useNavigate
import '../BackgroundStyles.css';
import axios from 'axios';

export default function Register() {
  const [userData, setUserData] = useState({
    userId: '',
    name: '',
    email: '',
    password: '',
  });

  const navigate = useNavigate();  // <-- initialize navigate

  const handleChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/register', userData);
      alert('User registered successfully!');
      console.log(response.data);
      setUserData({ userId: '', name: '', email: '', password: '' }); // clear form after success
    } catch (error) {
      console.error('Registration failed:', error);
      alert('Registration failed. Please check the server.');
    }
  };

  // New function for login button click
  const goToLogin = () => {
    navigate('/login');  // <-- change '/login' if your login route is different
  };

  return (
    <div className="page-container" style={{ backgroundImage: "url('/register-bg.jpg')" }}>
      <div className="form-container">
        <h2>Register</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="userId"
            placeholder="User ID"
            value={userData.userId}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={userData.name}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={userData.email}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={userData.password}
            onChange={handleChange}
            required
          />
          <button type="submit">Register</button>
        </form>
        {/* Login button added here */}
        <button onClick={goToLogin} style={{ marginTop: '10px' }}>
          Go to Login
        </button>
      </div>
    </div>
  );
}
