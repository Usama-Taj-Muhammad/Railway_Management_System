import React, { useEffect, useState } from 'react';
import '../BackgroundStyles.css';

export default function TrainList() {
  const [trains, setTrains] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    fetch('http://localhost:5002/api/trains', { signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to fetch trains: ${res.status}`);
        return res.json();
      })
      .then((data) => {
        setTrains(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.name === 'AbortError' ? 'Request timed out' : err.message);
        setLoading(false);
      });

    return () => clearTimeout(timeoutId);
  }, []);

  if (loading)
    return <p style={{ color: 'white', textAlign: 'center', marginTop: '20px' }}>Loading trains...</p>;
  if (error)
    return <p style={{ color: 'red', textAlign: 'center', marginTop: '20px' }}>Error: {error}</p>;

  return (
    <div className="page-container" style={{ backgroundImage: "url('/trainlist-bg.jpg')" }}>
      <div className="form-container" style={{ maxWidth: '700px' }}>
        <h2 style={{ color: '#fff', textAlign: 'center' }}>Available Trains</h2>
        {trains.length === 0 ? (
          <p style={{ color: 'white', textAlign: 'center' }}>No trains found.</p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0, color: 'white' }}>
            {trains.map((train) => (
              <li
                key={train._id}
                style={{
                  padding: '10px',
                  marginBottom: '10px',
                  background: 'rgba(255, 255, 255, 0.1)',
                  borderRadius: '10px',
                }}
              >
                <strong>{train.name}</strong> <br />
                Source: {train.source} | Destination: {train.destination} <br />
                Departure: {train.departureTime} | Arrival: {train.arrivalTime} <br />
                Seats Available: {train.seatsAvailable}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
