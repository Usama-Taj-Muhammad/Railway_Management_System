import axios from 'axios';

const API = {
  registerUser: (data) => axios.post('http://localhost:5000/api/register', data),

  loginUser: (data) => axios.post('http://localhost:5000/api/login', data),

  getTrains: () => axios.get('http://localhost:5002/api/trains'),

  bookTicket: (data) => axios.post('http://localhost:5003/api/bookings', data),

  getUsers: () => axios.get('http://localhost:5004/api/users'), // If you fetch users from user-service
};

export default API;
