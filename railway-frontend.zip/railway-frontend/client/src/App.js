import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import MainPage from './pages/MainPage';
import Register from './pages/Register';
import Login from './pages/Login';
import TrainList from './pages/TrainList';
import Booking from './pages/Booking';
import AddTrain from './pages/AddTrain';  // AddTrain component import

import './App.css';

export default function App() {
  return (
    <Router>
      <nav className="navbar">
        <Link to="/" className="nav-link">Home</Link>
        <Link to="/register" className="nav-link">Register</Link>
        <Link to="/login" className="nav-link">Login</Link>
        <Link to="/trains" className="nav-link">Trains</Link>
        <Link to="/addtrain" className="nav-link">Add Train</Link>  {/* New link */}
        <Link to="/booking" className="nav-link">Booking</Link>
      </nav>

      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/trains" element={<TrainList />} />
        <Route path="/addtrain" element={<AddTrain />} />  {/* New route */}
        <Route path="/booking" element={<Booking />} />
      </Routes>
    </Router>
  );
}
